-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : lun. 17 oct. 2022 à 13:35
-- Version du serveur : 10.4.24-MariaDB
-- Version de PHP : 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `cinestars`
--

-- --------------------------------------------------------

--
-- Structure de la table `alertesortie`
--

CREATE TABLE `alertesortie` (
  `idAlerteSortie` int(11) NOT NULL,
  `imgAlerteSortie` varchar(500) NOT NULL,
  `nomAlerteSortie` varchar(255) NOT NULL,
  `dateAlerteSortie` date NOT NULL,
  `idFilm` int(11) NOT NULL,
  `idUser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `avatars`
--

CREATE TABLE `avatars` (
  `idAvatar` int(11) NOT NULL,
  `img` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `avatars`
--

INSERT INTO `avatars` (`idAvatar`, `img`, `name`) VALUES
(1, 'https://zupimages.net/up/22/37/tea6.png', 'vador'),
(2, 'https://zupimages.net/up/22/37/jyvg.png', 'stormtrooper'),
(3, 'https://zupimages.net/up/22/37/sovy.png', 'Jango Fett'),
(4, 'https://zupimages.net/up/22/37/tg9t.png', 'K-2SO'),
(5, 'https://zupimages.net/up/22/37/4lc3.png', 'Terminator'),
(6, 'https://zupimages.net/up/22/37/k68j.png', 'Néo'),
(7, 'https://zupimages.net/up/22/37/95cu.png', 'Chaplin'),
(8, 'https://zupimages.net/up/22/37/89y0.png', 'Spiderman'),
(9, 'https://zupimages.net/up/22/37/bi61.png', 'Batman'),
(10, 'https://zupimages.net/up/22/37/k6a0.png', 'Black Panther'),
(11, 'https://zupimages.net/up/22/37/1wkm.png', 'Bat Girl'),
(12, 'https://zupimages.net/up/22/37/o3ba.png', 'DeadPool'),
(13, 'https://zupimages.net/up/22/37/bl4d.png', 'Jack Sparrow'),
(14, 'https://zupimages.net/up/22/37/ssa3.png', 'Morpheus'),
(15, 'https://zupimages.net/up/22/37/dq9j.png', 'Trinity'),
(16, 'https://zupimages.net/up/22/37/29oz.png', 'Walter White'),
(17, 'https://zupimages.net/up/22/37/xkbk.png', 'Boba Fett'),
(18, 'https://zupimages.net/up/22/37/qnzn.png', 'C3PO'),
(19, 'https://zupimages.net/up/22/37/j2t2.png', 'Dark Maul'),
(20, 'https://zupimages.net/up/22/37/llvc.png', 'Kenobi'),
(21, 'https://zupimages.net/up/22/37/37zm.png', 'Femme1'),
(22, 'https://zupimages.net/up/22/37/i47f.png', 'Homme1'),
(23, 'https://zupimages.net/up/22/37/vc7f.png', 'Femme2'),
(24, 'https://zupimages.net/up/22/37/ef6n.png', 'Femme3'),
(25, 'https://zupimages.net/up/22/37/eu8a.png', 'Homme2'),
(26, 'https://zupimages.net/up/22/37/vu8h.png', 'Femme4'),
(27, 'https://zupimages.net/up/22/37/64vi.png', 'Homme3'),
(28, 'https://zupimages.net/up/22/37/2w08.png', 'Homme4'),
(29, 'https://zupimages.net/up/22/37/suwm.png', 'Casquette'),
(30, 'https://zupimages.net/up/22/37/0637.png', 'Homme5'),
(31, 'https://zupimages.net/up/22/37/7o1f.png', 'Homme6'),
(32, 'https://zupimages.net/up/22/37/6tla.png', 'Homme7'),
(33, 'https://zupimages.net/up/22/37/gqu0.png', 'Homme8'),
(34, 'https://zupimages.net/up/22/37/c29m.png', 'Homme9'),
(35, 'https://zupimages.net/up/22/37/or1m.png', 'R2D2'),
(36, 'https://zupimages.net/up/22/37/f3t7.png', 'Dragon');

-- --------------------------------------------------------

--
-- Structure de la table `commentaire`
--

CREATE TABLE `commentaire` (
  `idCommentaire` int(11) NOT NULL,
  `commentaire` text NOT NULL,
  `idFilm` int(11) NOT NULL,
  `nameFilm` varchar(255) NOT NULL,
  `nameSerie` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `datenow` varchar(150) NOT NULL,
  `idUser` int(11) NOT NULL,
  `avatar_img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `commentaire`
--

INSERT INTO `commentaire` (`idCommentaire`, `commentaire`, `idFilm`, `nameFilm`, `nameSerie`, `type`, `datenow`, `idUser`, `avatar_img`) VALUES
(49, 'S&eacute;rie au TOP !! Vivement la suite des &eacute;pisodes !!', 84773, '', 'Le Seigneur des anneaux : Les Anneaux de pouvoir', 'tv', '08-09-2022 à 09:02:53', 2, 'https://zupimages.net/up/22/37/tea6.png'),
(50, 'Stallone comment a se faire vieux pour ce genre de film.. A regarder si on a rien &agrave; faire.', 629176, 'Le Samaritain', '', 'movie', '09-09-2022 à 17:17:53', 2, 'https://zupimages.net/up/22/37/tea6.png'),
(51, 'nul', 616037, 'Thor : Love and Thunder', '', 'movie', '08-09-2022 à 14:17:53', 8, 'https://zupimages.net/up/22/37/vc7f.png'),
(52, 'personne n&#039;a besoin de ce film', 76600, 'Avatar : La Voie de l\'eau', '', 'movie', '08-09-2022 à 18:35:53', 8, 'https://zupimages.net/up/22/37/vc7f.png'),
(53, 'trop pipou', 1010818, 'Les Premiers Pas de Groot', '', 'movie', '08-09-2022 à 14:35:53', 8, 'https://zupimages.net/up/22/37/vc7f.png'),
(54, 'mouais inutile', 634649, 'Spider-Man: No Way Home', '', 'movie', '08-09-2022 à 10:17:53', 8, 'https://zupimages.net/up/22/37/vc7f.png'),
(55, 'grave cool sauf la derni&egrave;re saison', 1399, '', 'Game of Thrones', 'tv', '08-09-2022 à 14:47:53', 8, 'https://zupimages.net/up/22/37/vc7f.png'),
(56, '&Ccedil;a devient p&eacute;nible que Disney fasse des &eacute;pisodes de 30 min.. et les effets sp&eacute;ciaux de she-hulk laissent &agrave; d&eacute;sirer. Sinon pour l&#039;instant c&#039;est plut&ocirc;t pas mal. ', 92783, '', 'She-Hulk : Avocate', 'tv', '09-09-2022 à 12:22:53', 2, 'https://zupimages.net/up/22/37/tea6.png'),
(58, 'Si moi !! J&#039;en ai vraiment besoin !! C&#039;est un besoin vital !', 76600, 'Avatar : La Voie de l\'eau', '', 'movie', '08-09-2022 à 19:47:53', 2, 'https://zupimages.net/up/22/37/tea6.png'),
(59, 'C&#039;&eacute;tait le matrix de trop...', 624860, 'Matrix Resurrections', '', 'movie', '10-09-2022 à 09:44:50', 2, 'https://zupimages.net/up/22/37/tea6.png'),
(60, '28 ans apr&egrave;s... 28 ans &agrave; voir la suite du manga en anim&eacute;.  Enfin !!', 96884, '', 'Dragon Quest : La Quête de Daï', 'tv', '11-09-2022 à 00:07:27', 2, 'https://zupimages.net/up/22/37/tea6.png'),
(61, 'Le meilleur manga !!\r\nA voir absolument !!!', 13916, '', 'Death Note', 'tv', '11-09-2022 à 09:40:39', 2, 'https://zupimages.net/up/22/37/tea6.png'),
(62, 'Trop cool le nouveau Shrek', 92783, '', 'She-Hulk : Avocate', 'tv', '13-09-2022 à 10:53:06', 4, 'https://zupimages.net/up/22/37/vc7f.png'),
(63, 'pas si nul que &ccedil;a en r&eacute;alit&eacute;', 616037, 'Thor : Love and Thunder', '', 'movie', '13-09-2022 à 10:59:15', 12, 'https://zupimages.net/up/22/37/vc7f.png'),
(64, 'Trop cool le nouveau Shrek', 92783, '', 'She-Hulk : Avocate', 'tv', '13-09-2022 à 11:39:35', 4, 'https://zupimages.net/up/22/37/vc7f.png'),
(65, 'Trop cool le nouveau Shrek', 92783, '', 'She-Hulk : Avocate', 'tv', '13-09-2022 à 11:39:41', 4, 'https://zupimages.net/up/22/37/vc7f.png'),
(66, 'Trop cool le nouveau Shrek', 92783, '', 'She-Hulk : Avocate', 'tv', '13-09-2022 à 11:39:51', 4, 'https://zupimages.net/up/22/37/vc7f.png'),
(67, 'Trop cool le nouveau Shrek', 92783, '', 'She-Hulk : Avocate', 'tv', '13-09-2022 à 11:39:52', 4, 'https://zupimages.net/up/22/37/vc7f.png'),
(68, 'Trop cool le nouveau Shrek', 92783, '', 'She-Hulk : Avocate', 'tv', '13-09-2022 à 11:39:52', 4, 'https://zupimages.net/up/22/37/vc7f.png'),
(69, 'Trop cool le nouveau Shrek', 92783, '', 'She-Hulk : Avocate', 'tv', '13-09-2022 à 11:39:53', 4, 'https://zupimages.net/up/22/37/vc7f.png'),
(70, 'J&#039;adore vraiment !', 667933, '異常性告白　私に毛を下さい', '', 'movie', '16-09-2022 à 08:40:32', 4, 'https://zupimages.net/up/22/37/29oz.png'),
(71, 'Magnifique film digne des plus grands\r\n', 419396, 'Gender Me: Homosexuality and Islam', '', 'movie', '16-09-2022 à 09:24:11', 4, 'https://zupimages.net/up/22/37/jyvg.png'),
(72, 'Pas si mal que &ccedil;a. &Ccedil;a se laisse regarder.', 203555, '', 'The Imperfects', 'tv', '16-09-2022 à 20:39:56', 2, 'https://zupimages.net/up/22/37/tea6.png'),
(75, 'vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc', 76600, 'Avatar : La Voie de l\'eau', '', 'movie', '16-09-2022 à 21:35:54', 2, 'https://zupimages.net/up/22/37/tea6.png'),
(76, 'Vivement !!', 642885, 'Hocus Pocus 2', '', 'movie', '17-09-2022 à 13:46:48', 2, 'https://zupimages.net/up/22/37/tea6.png'),
(77, 'C&#039;est m&ecirc;me plut&ocirc;t pas mal et il y a des passages o&ugrave; &ccedil;a m&#039;a bien fait marrer :D', 616037, 'Thor : Love and Thunder', '', 'movie', '17-09-2022 à 23:53:13', 2, 'https://zupimages.net/up/22/37/tea6.png'),
(78, 'Excellent film!', 361743, 'Top Gun: Maverick', '', 'movie', '18-09-2022 à 10:07:44', 19, 'https://zupimages.net/up/22/37/vu8h.png'),
(79, 'A CHIER !!!', 83867, '', 'Star Wars: Andor', 'tv', '22-09-2022 à 09:21:38', 2, 'https://zupimages.net/up/22/37/tea6.png'),
(80, 'RE A CHIER', 83867, '', 'Star Wars: Andor', 'tv', '22-09-2022 à 09:22:11', 2, 'https://zupimages.net/up/22/37/tea6.png'),
(81, 'sdfsdfsdf', 83867, '', 'Star Wars: Andor', 'tv', '22-09-2022 à 09:28:36', 1, 'https://zupimages.net/up/22/37/k6a0.png');

-- --------------------------------------------------------

--
-- Structure de la table `favoris`
--

CREATE TABLE `favoris` (
  `idFavoris` int(11) NOT NULL,
  `imgFavoris` varchar(255) NOT NULL,
  `nomFilmFavoris` varchar(255) NOT NULL,
  `nomSerieFavoris` varchar(255) NOT NULL,
  `dateSortieFavoris` date NOT NULL,
  `type` varchar(30) NOT NULL,
  `idFilm` int(11) NOT NULL,
  `idUser` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `favoris`
--

INSERT INTO `favoris` (`idFavoris`, `imgFavoris`, `nomFilmFavoris`, `nomSerieFavoris`, `dateSortieFavoris`, `type`, `idFilm`, `idUser`) VALUES
(18, '/q6YlGKA7iZzKF32UsuUuYVLfHVa.jpg', 'Les Premiers Pas de Groot', '', '2022-08-10', 'movie', 1010818, 8),
(19, '/mUKm5eaYm30KYyaudRn5tA204ua.jpg', 'Drive', '', '2011-09-15', 'movie', 64690, 8),
(20, '/coIfrLBnLBC88QkHk703vIoyJXl.jpg', 'The Place Beyond the Pines', '', '2013-03-14', 'movie', 97367, 8),
(21, '/doJ6axLfzLCDaPqFSSHjaSTYKb2.jpg', '', 'Marvel\'s Daredevil', '2015-04-10', 'tv', 61889, 8),
(41, '/xrkDlkL6u26DLeBw2Cao8pYtrYH.jpg', '', 'Moon Knight', '2022-03-30', 'tv', 92749, 12),
(42, '/3SyG7dq2q0ollxJ4pSsrqcfRmVj.jpg', 'Spider-Man: No Way Home', '', '2021-12-15', 'movie', 634649, 12),
(45, '/9j21DXo7Gwtfxj81iC20AbOqumt.jpg', 'Venom: Let There Be Carnage', '', '2021-09-30', 'movie', 580489, 12),
(46, '/gpHezxjqAnZ21o8T9vSSrUKygQ3.jpg', '', 'Le seigneur des anneaux : les anneaux de pouvoir', '2022-09-01', 'tv', 84773, 12),
(47, '/tQfNmfmapJVp1nPE0WFjswpK1Zo.jpg', '', 'House of the Dragon', '2022-08-21', 'tv', 94997, 12),
(50, '/kTh1s6I6yUyk2OGiRoGkDTYTS6K.jpg', 'Top Gun: Maverick', '', '2022-05-24', 'movie', 361743, 22),
(51, '/tlUwoyuAJqcNnKzSr0f7541jeAP.jpg', '', 'The Good Fight', '2017-02-19', 'tv', 69158, 22),
(54, '/kSMarEm3ESOOr11dzsep2RZ1ClD.jpg', 'Thor : Love and Thunder', '', '2022-07-06', 'movie', 616037, 1),
(55, '/gpHezxjqAnZ21o8T9vSSrUKygQ3.jpg', '', 'Le seigneur des anneaux : les anneaux de pouvoir', '2022-09-01', 'tv', 84773, 1),
(67, '/gpHezxjqAnZ21o8T9vSSrUKygQ3.jpg', '', 'Le Seigneur des anneaux : Les Anneaux de pouvoir', '2022-09-01', 'tv', 84773, 2),
(70, '/kSMarEm3ESOOr11dzsep2RZ1ClD.jpg', 'Thor : Love and Thunder', '', '2022-07-06', 'movie', 616037, 2),
(71, '/tQfNmfmapJVp1nPE0WFjswpK1Zo.jpg', '', 'House of the Dragon', '2022-08-21', 'tv', 94997, 2);

-- --------------------------------------------------------

--
-- Structure de la table `session`
--

CREATE TABLE `session` (
  `idSession` int(11) NOT NULL,
  `idUser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `session`
--

INSERT INTO `session` (`idSession`, `idUser`) VALUES
(66, 1),
(111, 1),
(51, 2),
(56, 2),
(63, 2),
(69, 2),
(81, 2),
(84, 2),
(85, 2),
(89, 2),
(91, 2),
(93, 2),
(99, 2),
(100, 2),
(44, 3),
(47, 4),
(73, 4),
(96, 4),
(49, 5),
(60, 8),
(62, 9),
(72, 12),
(77, 14),
(95, 19),
(97, 22),
(98, 23);

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `idUser` int(11) NOT NULL,
  `pseudo` varchar(30) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(100) NOT NULL,
  `avatar` varchar(255) NOT NULL DEFAULT 'https://zupimages.net/up/22/37/vc7f.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`idUser`, `pseudo`, `email`, `password`, `avatar`) VALUES
(1, 'admin', 'dev@cinestars.fr', '$argon2i$v=19$m=65536,t=4,p=1$Vmp5YkgvenJITEhmdnJjbg$whVfQJVzhPNXegaCaCQt72eBIqIOPrbnZIJ+LR7nbL4', 'https://zupimages.net/up/22/37/k6a0.png'),
(2, 'horn', 'sebastien.mauro@gmail.com', '$argon2i$v=19$m=65536,t=4,p=1$VTl2aHBhdTBZdU16LzF3eQ$f50NYPaVJ3SDAp51ONUQnbv/6al4FEw6WCELrCRHdAc', 'https://zupimages.net/up/22/37/tea6.png'),
(3, 'Michael', 'mmichaell62400@gmail.com', '$argon2i$v=19$m=65536,t=4,p=1$Z2R4d1hEZWNwV2RleGozQQ$LBOe7BHGjhdqfTRQKEfwFL3ET4XQk9h2x5cThhoLX+A', 'https://zupimages.net/up/22/37/vc7f.png'),
(4, 'Jeenius', 'herisson-23@hotmail.fr', '$argon2i$v=19$m=65536,t=4,p=1$dGNyLnBwVnJYZXZHQ0dLUg$3QycohsuW1qbpEhLEg7hmi3hOL7xzCKqWavidbOoV9E', 'https://zupimages.net/up/22/37/k6a0.png'),
(5, 'Funkins', 'floflocrespel@gmail.com', '$argon2i$v=19$m=65536,t=4,p=1$dHhiSHlsRnk3NWd6TXpyUw$pV8OSY98+90eIpr7RMg3Kg95B7Dy7hwaQD4wcuuZW/Q', 'https://zupimages.net/up/22/37/vc7f.png'),
(7, 'Alice', 'aliceinwonderland@gmail.com', '$argon2i$v=19$m=65536,t=4,p=1$bXRoR0FjcDlOak1CYUxKaQ$1nqmwRYJmSjHqZaYGj5hCJ+14QxKcd24jFhOzPxVSmU', 'https://zupimages.net/up/22/37/vc7f.png'),
(8, 'shina', 'shinaisplaying@gmail.com', '$argon2i$v=19$m=65536,t=4,p=1$NWFsOFNpNGZMQ1g3a1FKQQ$1OfSFUq5Chetcenxmjv+gVlLci2+Y5vQVKsVkmHWAkk', 'https://zupimages.net/up/22/37/vc7f.png'),
(9, 'maximike', 'michael1@gmail.com', '$argon2i$v=19$m=65536,t=4,p=1$TVJMbkVlWExrc1c3OUhEbg$Uvz8vsh2iWaL63Lt9m/X3WDsqbSNlgeZ2SkE0svBEMU', 'https://zupimages.net/up/22/37/vc7f.png'),
(10, 'Jeenius', 'shaokahngoro-23@hotmail.com', '$argon2i$v=19$m=65536,t=4,p=1$MDNoYWVYbzVsN0tlMnRsRw$bh1moeWpZ3U+fcxT53mUpClfVE87BRUcftXWKcUu+9c', 'https://zupimages.net/up/22/37/vc7f.png'),
(11, 'idiya', 'idiya@gmail.com', '$argon2i$v=19$m=65536,t=4,p=1$YnBsb3pmak1ZNGpMMm96eg$vC6905GShn/Sthovkuqt2jtULg3Rtfwsmd/a7at12BY', 'https://zupimages.net/up/22/37/vc7f.png'),
(12, 'maxi_mike', 'mic@gmail.com', '$argon2i$v=19$m=65536,t=4,p=1$WmEyVXlVNi9QRU16QnN4bg$SsrC2lpSurtup+a4Afc1kXuvESJgwwbxv1wtleIEaR0', 'https://zupimages.net/up/22/37/vc7f.png'),
(13, 'michael', 'michael24@gmail.com', '$argon2i$v=19$m=65536,t=4,p=1$Si9la1E5T1BMVWdJWUNFSA$lIGJd93FLBUPP9ejz8zfR3ArVH3nK1BZi17tVq+/6PU', 'https://zupimages.net/up/22/37/vc7f.png'),
(14, 'michael2410', 'michael2410@gmail.com', '$argon2i$v=19$m=65536,t=4,p=1$UkpvMWpVOGYzcm5KaFlxbA$gA5wboNOAOi+rZRcagS6QM5R7fQNWi+qzzw0OIaFnek', 'https://zupimages.net/up/22/37/vc7f.png'),
(16, 'bobo', 'bobo@sdf.fr', '$argon2i$v=19$m=65536,t=4,p=1$ZWdoVkRGTHB0VERaVGxIVw$X01fM85bN5MQZC573wfH3slc7sNACIk+hKUusZVb/CM', 'https://zupimages.net/up/22/37/sovy.png'),
(19, 'Claire', 'claire.h1007@gmail.com', '$argon2i$v=19$m=65536,t=4,p=1$dHBzaXcyOS5mbXVuVExzWA$1nEXPDifEQ6AilpOqQGPZ1Pz71fF2fY0uGCcW97n9tc', 'https://zupimages.net/up/22/37/vu8h.png'),
(22, 'Auka', 'Celmelek@laposte.net', '$argon2i$v=19$m=65536,t=4,p=1$d0c5M1FHbWxudmN0ejlFcw$GpbAfR91iFjVIjmFGeGHR+S+zibZ7ThTt2o/GvpdUyM', 'https://zupimages.net/up/22/37/1wkm.png'),
(23, 'Victoria.lep', 'Victoria.lepore@outlook.fr', '$argon2i$v=19$m=65536,t=4,p=1$LzliQ1JiaHBTa2E4Mk90bA$+ytFtXxtsacQARrgu4Fe5WFv8FtdEP0dTL/uFso2+AU', 'https://zupimages.net/up/22/37/vc7f.png');

-- --------------------------------------------------------

--
-- Structure de la table `user_favori_film`
--

CREATE TABLE `user_favori_film` (
  `idFavoris` int(11) NOT NULL,
  `idUser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `user_favori_film`
--

INSERT INTO `user_favori_film` (`idFavoris`, `idUser`) VALUES
(18, 8),
(19, 8),
(20, 8),
(21, 8),
(41, 12),
(42, 12),
(45, 12),
(46, 12),
(47, 12),
(50, 22),
(51, 22),
(54, 1),
(55, 1),
(67, 2),
(70, 2),
(71, 2);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `alertesortie`
--
ALTER TABLE `alertesortie`
  ADD PRIMARY KEY (`idAlerteSortie`),
  ADD KEY `ALERTESORTIE_USER_FK` (`idUser`);

--
-- Index pour la table `avatars`
--
ALTER TABLE `avatars`
  ADD PRIMARY KEY (`idAvatar`);

--
-- Index pour la table `commentaire`
--
ALTER TABLE `commentaire`
  ADD PRIMARY KEY (`idCommentaire`),
  ADD KEY `COMMENTAIRE_USER_FK` (`idUser`);

--
-- Index pour la table `favoris`
--
ALTER TABLE `favoris`
  ADD PRIMARY KEY (`idFavoris`);

--
-- Index pour la table `session`
--
ALTER TABLE `session`
  ADD PRIMARY KEY (`idSession`),
  ADD KEY `session_user0_FK` (`idUser`) USING BTREE;

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`idUser`);

--
-- Index pour la table `user_favori_film`
--
ALTER TABLE `user_favori_film`
  ADD PRIMARY KEY (`idFavoris`,`idUser`),
  ADD KEY `user_favori_film_USER0_FK` (`idUser`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `alertesortie`
--
ALTER TABLE `alertesortie`
  MODIFY `idAlerteSortie` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `avatars`
--
ALTER TABLE `avatars`
  MODIFY `idAvatar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT pour la table `commentaire`
--
ALTER TABLE `commentaire`
  MODIFY `idCommentaire` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT pour la table `favoris`
--
ALTER TABLE `favoris`
  MODIFY `idFavoris` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT pour la table `session`
--
ALTER TABLE `session`
  MODIFY `idSession` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `idUser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `alertesortie`
--
ALTER TABLE `alertesortie`
  ADD CONSTRAINT `ALERTESORTIE_USER_FK` FOREIGN KEY (`idUser`) REFERENCES `user` (`idUser`);

--
-- Contraintes pour la table `commentaire`
--
ALTER TABLE `commentaire`
  ADD CONSTRAINT `COMMENTAIRE_USER_FK` FOREIGN KEY (`idUser`) REFERENCES `user` (`idUser`);

--
-- Contraintes pour la table `session`
--
ALTER TABLE `session`
  ADD CONSTRAINT `session_user0_FK` FOREIGN KEY (`idUser`) REFERENCES `user` (`idUser`);

--
-- Contraintes pour la table `user_favori_film`
--
ALTER TABLE `user_favori_film`
  ADD CONSTRAINT `user_favori_film_FAVORIS_FK` FOREIGN KEY (`idFavoris`) REFERENCES `favoris` (`idFavoris`),
  ADD CONSTRAINT `user_favori_film_USER0_FK` FOREIGN KEY (`idUser`) REFERENCES `user` (`idUser`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
